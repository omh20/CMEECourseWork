#!bin/bash
# Author: Olivia o.haas20@imperial.ac.uk
# Script@ boilerplate.sh
# Desc: simple boilerplate for shell scripts
# Arguments: none
# Date: Oct 2020

echo -e "\n This is a shell script! \n"

#exit